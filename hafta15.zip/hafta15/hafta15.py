import threading

def coder(number,number1):
    print(f'Coder ID: {number},{number1}')

threads = []
for k in range(5):
  for c in range(5):
         t = threading.Thread(target=coder, args=(k, c))
         threads.append(t)
         t.start()